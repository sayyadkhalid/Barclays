﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        static string[] versions = new string[] { "-v", "--v", "/v", "--version" };
        static string[] sizes = new string[] { "-s", "--s", "/ s", "--size" };
        public static void Main(string[] args)
        {
            Console.WriteLine(args[0] +" - "+ args[1]);

            var collection = new ServiceCollection().AddSingleton<FileDetails>(new FileDetails());
            var serviceProvider = collection.BuildServiceProvider();
            
            //FileDetails fd = new FileDetails();
            if (args.Length > 0)
            {
                bool allfalse = false;
                if (versions.Contains(args[0]))
                {
                    //Console.WriteLine(fd.Version(args[1]));
                    Console.WriteLine("FileDetails.Version:" + serviceProvider.GetService<FileDetails>().Version(args[1]));
                    allfalse = true;
                }
                else if (sizes.Contains(args[0]))
                {
                    //Console.WriteLine(fd.Size(args[1]));
                    Console.WriteLine("FileDetails.Size:"+serviceProvider.GetService<FileDetails>().Size(args[1]));
                    allfalse = true;
                }
                if (allfalse == false)
                {
                    Console.WriteLine("Wrong version/size mentioned, Please modify arguments");
                }
            }

            Console.ReadLine();
        }

        
    }
}
