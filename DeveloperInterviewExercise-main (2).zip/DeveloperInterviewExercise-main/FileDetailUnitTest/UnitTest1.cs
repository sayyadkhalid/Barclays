﻿using System;
using System.Text.RegularExpressions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ThirdPartyTools;

namespace FileDetailUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CheckSizeValidTest()
        {
            var collection = new ServiceCollection().AddSingleton<FileDetails>(new FileDetails());
            var serviceProvider = collection.BuildServiceProvider();
            int size = serviceProvider.GetService<FileDetails>().Size("c:/test");
            int number;
            bool isValid = int.TryParse("" + size, out number);
            Assert.IsTrue(isValid);
        }

        [TestMethod]
        public void CheckVersionValidTest()
        {
            var collection = new ServiceCollection().AddSingleton<FileDetails>(new FileDetails());
            var serviceProvider = collection.BuildServiceProvider();
            string version = serviceProvider.GetService<FileDetails>().Version("c:/test");
            string expr = @"^[0-9]\d*(\.[0-9]\d*)*$";

            bool ismatched=Regex.IsMatch(version, expr);
            Assert.IsTrue(ismatched);
        }
    }
}
